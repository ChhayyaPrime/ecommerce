-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2024 at 07:24 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_product`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `pro_id` int(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `img` varchar(50) NOT NULL,
  `size` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `point` varchar(500) NOT NULL,
  `action` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`pro_id`, `name`, `img`, `size`, `price`, `point`, `action`) VALUES
(45, 'Man Cloths', 'men-02.jpg', 'Large', 100.00, 'New product', ''),
(46, 'Man Cloths', 'men-03.jpg', 'Large', 130.00, 'New product', ''),
(47, '	Man Cloths', 'men-01.jpg', 'Large', 150.00, 'New product', ''),
(54, '	Man Cloths', 'man3.jpg', 'Large', 279.00, 'New product', ''),
(56, '	Man Cloths', 'man6.jpg', 'Large', 320.00, 'New product', ''),
(57, '	Man Cloths', '92063.jpg', 'Large', 199.00, 'New product', ''),
(58, '	Man Cloths', 'f0ef114d-a425-45b7-9eff-adaf4ca1d821.jpg', 'Large', 189.00, 'New product', ''),
(59, '	Man Cloths', '153351611-117075921-1681290348.jpg', 'Large', 150.00, '0', ''),
(60, '	Man Cloths', '92063.jpg', 'Large', 200.00, '0', ''),
(61, '	Women Cloths', 'women-01.jpg', 'Large', 149.00, '0', ''),
(62, '	Women Cloths', 'women-02.jpg', 'Large', 150.00, '0', ''),
(63, '	Women Cloths', 'women-03.jpg', 'Large', 170.00, '0', ''),
(64, '	Women Cloths', 'instagram-01.jpg', 'Large', 220.00, '0', ''),
(68, '	Women Cloths', 'instagram-01.jpg', 'Large', 200.00, '0', ''),
(69, '	Women Cloths', 'explore-image-02.jpg', 'Large', 200.00, '0', ''),
(70, '	Women Cloths', 'instagram-03.jpg', 'Large', 200.00, '0', ''),
(71, '	Women Cloths', 'instagram-03.jpg', 'Large', 200.00, '0', ''),
(72, '	Women Cloths', 'explore-image-02.jpg', 'Large', 200.00, '0', ''),
(73, 'Kid Cloths', 'kid0.jpg', 'Small', 55.00, '0', ''),
(78, 'Kid Cloths', 'kid2.jpg', 'Small', 70.00, '0', ''),
(79, 'Kid Cloths', 'kid0.jpg', 'Small', 60.00, '0', ''),
(80, 'Kid Cloths', 'kid-03.jpg', 'Small', 60.00, '0', ''),
(81, 'Kid Cloths', 'kid-02.jpg', 'Small', 60.00, '0', ''),
(82, 'Kid Cloths', 'kid-01.jpg', 'Large', 65.00, '0', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `user_id` int(20) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`user_id`, `user_name`, `email`, `password`) VALUES
(1, 'chhayya', 'chhayya@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_female`
--

CREATE TABLE `tbl_female` (
  `pro_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `img` varchar(1000) NOT NULL,
  `size` int(50) NOT NULL,
  `price` varchar(1000) NOT NULL,
  `point` mediumtext NOT NULL,
  `action` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_female`
--

INSERT INTO `tbl_female` (`pro_id`, `name`, `img`, `size`, `price`, `point`, `action`) VALUES
(1, 'Srey', 'Chhayya Pic.jpg', 0, '55', '3', ''),
(2, 'Women Cloths', 'instagram-03.jpg', 0, '300', 'New product', ''),
(3, 'Women Cloths', 'explore-image-02.jpg', 0, '240', 'New product', ''),
(4, 'Women Cloths', 'baner-right-image-01.jpg', 0, '250', 'New product', ''),
(5, 'Women Cloths', 'instagram-01.jpg', 0, '270', 'New product', ''),
(6, 'Women Cloths', 'women-01.jpg', 0, '270', 'New product', ''),
(7, 'Women Cloths', 'women-02.jpg', 0, '150', 'New product', ''),
(8, 'Women Cloths', 'women-03.jpg', 0, '170', 'New product', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kid`
--

CREATE TABLE `tbl_kid` (
  `pro_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `img` varchar(1000) NOT NULL,
  `size` varchar(50) NOT NULL,
  `price` varchar(1000) NOT NULL,
  `point` mediumtext NOT NULL,
  `action` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_kid`
--

INSERT INTO `tbl_kid` (`pro_id`, `name`, `img`, `size`, `price`, `point`, `action`) VALUES
(2, 'New For Kid', 'kid0.jpg', 'Small', '25', 'New product', ''),
(3, 'New For Kid', 'kid1.jpg', 'Small', '30', 'New product', ''),
(4, 'New For Kid', 'kid2.jpg', 'Small', '40', 'New product', ''),
(5, 'New For Kid', 'kid5.jpg', 'Small', '35', 'New product', ''),
(6, 'New For Kid', 'baner-right-image-03.jpg', 'Small', '45', 'New product', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_male`
--

CREATE TABLE `tbl_male` (
  `pro_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `img` varchar(1000) NOT NULL,
  `size` varchar(50) NOT NULL,
  `price` varchar(1000) NOT NULL,
  `point` mediumtext NOT NULL,
  `action` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_male`
--

INSERT INTO `tbl_male` (`pro_id`, `name`, `img`, `size`, `price`, `point`, `action`) VALUES
(1, 'chhayya', 'Chhayya Pic.jpg', 'Large', '55', '5', ''),
(2, 'Man Cloths', 'baner-right-image-02.jpg', 'Large', '70', 'New product', ''),
(3, 'Man Cloths', 'men-03.jpg', 'Large', '75', 'New product', ''),
(4, 'Man Cloths', 'men-01.jpg', 'Large', '55', 'New product', ''),
(5, 'Man Cloths', 'man0.jpg', 'Large', '230', 'New product', ''),
(6, 'Man Cloths', 'man2.jpg', 'Large', '200', 'New product', ''),
(7, 'Man Cloths', 'man6.jpg', 'Large', '250', 'New product', ''),
(8, 'Man Cloths', 'man4.jpg', 'Large', '80', 'New product', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `tbl_female`
--
ALTER TABLE `tbl_female`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `tbl_kid`
--
ALTER TABLE `tbl_kid`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `tbl_male`
--
ALTER TABLE `tbl_male`
  ADD PRIMARY KEY (`pro_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblproduct`
--
ALTER TABLE `tblproduct`
  MODIFY `pro_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `user_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_female`
--
ALTER TABLE `tbl_female`
  MODIFY `pro_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_kid`
--
ALTER TABLE `tbl_kid`
  MODIFY `pro_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_male`
--
ALTER TABLE `tbl_male`
  MODIFY `pro_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
