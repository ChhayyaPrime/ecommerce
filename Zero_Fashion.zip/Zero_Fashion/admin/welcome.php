<?php
   include('session.php');
?>
<html">
   
   <head>
      <title>Welcome </title>
   </head>
   
   <body> 
      <h2><a href = "logout.php">Sign Out</a></h2>
   </body>
   <!-- Php -->
   <!-- echo $login_session;
    -->
</html>