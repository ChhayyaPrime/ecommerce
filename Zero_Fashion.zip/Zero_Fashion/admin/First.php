<!DOCTYPE html>
<html>

<head>
    <title>DataTable</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">
    <script type="text/javascript" src="jquery-3.7.0.js"></script>
    <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#example').DataTable();
        });   
    </script>
</head>

<body>
    <h2><a href = "logout.php">Sign Out</a></h2>
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Product Name</th>
                <th>Picture</th>
                <th>Size</th>
                <th>Price</th>
                <th>Point</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
            include_once('../config.php');
            $query="SELECT * FROM `tblproduct`";
            $result=mysqli_query($conn,$query);
            if(mysqli_num_rows($result)>0){
                while($row=mysqli_fetch_array($result)){
                    echo"<tr>";
                    echo"<td>".$row['pro_id'];
                    echo"<td>".$row['name'];
                 ?>
                <td>
                    <img src="../images/<?php echo $row['img'];?>" width="100">
                </td>
                    <?php
                    echo"<td>".$row['size']."</td>";
                    echo"<td>".$row['price']."</td>";
                    echo"<td>".$row['point']."</td>";

                    // still not working yet

                    echo"<td>".$row['action'];
                    //this
                    ?>
                
                        <a href="edit_product.php?ProID=<?php echo $row['pro_id'];?>">Edit</a>
                        <a href="delete_ptoduct.php?ProID=<?php echo $row['pro_id'];?>">Delete</a>
                    </td>

                    <?php
                    echo"</tr>";
                
                }
            }

        ?>
        </tbody>
        <tfoot>
        </tfoot>
    </table>
</body>

</html>